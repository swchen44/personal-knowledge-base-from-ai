/*
 * Trace Recorder for Tracealyzer v989.878.767
 * Copyright 2023 Percepio AB
 * www.percepio.com
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Kernel port configuration parameters for snapshot mode.
 */

#ifndef TRC_KERNEL_PORT_SNAPSHOT_CONFIG_H
#define TRC_KERNEL_PORT_SNAPSHOT_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* TRC_KERNEL_PORT_SNAPSHOT_CONFIG_H */
